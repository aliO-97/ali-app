document.addEventListener("DOMContentLoaded", function() {
  const startButton = document.getElementById("startButton");
  const viewInfoButton = document.getElementById("viewInfoButton");
  const backToFormButton = document.getElementById("backToForm");
  const form = document.getElementById("infoForm");
  const infoTable = document.getElementById("infoTable").getElementsByTagName("tbody")[0];

  // Navigate to the form page when "Start" button is clicked
  if (startButton) {
    startButton.addEventListener("click", function() {
      window.location.href = "form.html"; // Ensure form.html exists in the same folder
    });
  }

  // Go to the display page when "View Entered Information" button is clicked
  if (viewInfoButton) {
    viewInfoButton.addEventListener("click", function() {
      window.location.href = "display.html"; // Ensure display.html exists in the same folder
    });
  }

  // Go back to the form page
  if (backToFormButton) {
    backToFormButton.addEventListener("click", function() {
      window.location.href = "form.html"; // Go back to form.html
    });
  }

  // Form submission to store and display data
  if (form) {
    form.addEventListener("submit", function(e) {
      e.preventDefault();

      const name = document.getElementById("name").value;
      const phone = document.getElementById("phone").value;
      const passportPhoto = document.getElementById("passportPhoto").files[0]?.name || "No photo uploaded";
      const done = document.getElementById("done").checked ? "True" : "False";

      // Save the form data in localStorage
      let storedData = JSON.parse(localStorage.getItem("data")) || [];
      storedData.push({ name, phone, passportPhoto, done });
      localStorage.setItem("data", JSON.stringify(storedData));

      // After saving, go to the display page
      window.location.href = "display.html"; // Navigate to display page
    });
  }

  // Populate the table with stored data on the display page
  if (window.location.pathname.includes("display.html")) {
    const storedData = JSON.parse(localStorage.getItem("data")) || [];

    storedData.forEach(entry => {
      const row = infoTable.insertRow();
      row.insertCell(0).innerText = entry.name;
      row.insertCell(1).innerText = entry.phone;
      row.insertCell(2).innerText = entry.passportPhoto;
      row.insertCell(3).innerText = entry.done;
    });
  }
});
